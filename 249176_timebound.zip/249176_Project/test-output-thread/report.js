$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"added858-e1f2-455f-b527-b000bfc700de","feature":"Login page feature","scenario":"Login page title","start":1695988450175,"group":1,"content":"","tags":"","end":1695988459138,"className":"passed"},{"id":"fa76a938-976c-422e-98ef-13d4afe61a4a","feature":"Login page feature","scenario":"Login with correct credentials","start":1695988459154,"group":1,"content":"","tags":"","end":1695988465499,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});