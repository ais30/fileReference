package ust.show.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.show.base.DriverUtils;

/**
 * This class represents a page object for the Main page of a web application.
 */
public class RegisterPage  extends DriverUtils{
	

	WebDriver driver;

	/**
     * Constructor for the MainPage class.
     *
     * @param driver The WebDriver instance to use for interacting with the page.
     */
	
	public RegisterPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	} 
	// WebElement declarations using @FindBy annotations
    // ...
	
	@FindBy(xpath="/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")
	 WebElement Login;
		
	 @FindBy(id="Email")
	 WebElement Email;
	 @FindBy(id="Password")
	 WebElement Password;
	 @FindBy(xpath="//button[@class='button-1 login-button']")
	 WebElement submit;
	 @FindBy(id="Email-error")
	 WebElement errorm;
	 @FindBy(id="FirstName")
	 WebElement FirstName;
	 @FindBy(id="LastName")
	 WebElement LastName;
	 @FindBy(id="Email")
	 WebElement Email1;
	 @FindBy(id="Password")
	 WebElement Password1;
	 @FindBy(id="ConfirmPassword")
	 WebElement ConfirmPassword;
	 @FindBy(id="register-button")
	 WebElement register;
	 @FindBy(xpath="//a[text()='Register']")
	 WebElement reg1;
	 
	 /*****	creating Methods to store the web elements *******/
	 public String getTitle() {
	 return driver.getTitle();
	 }
	 public String getLoginPageTitle() {
			return driver.getTitle();
		}
	 public void login() {
	 clickOn(Login);
	 }
	 public void Email(String email) {
	 sendtext(Email,email);
	 }
	 public void password(String uname) {
	 sendtext(Password,uname);
	 }
	 public void submit() {
	 clickOn(submit);
	 }
	 public String errorm()
	 {	
	 return rettext(errorm);
	 }
	 public void FirstName(String iname) {
	 sendtext(FirstName,iname);
	 }
	 public void Email1(String iemail) {
	 sendtext(Email,iemail);
	 }
	 public void Password1(String pwd) {
	 sendtext(Password,pwd);
	 }
	 public void LastName(String lname) {
	 sendtext(LastName,lname);
	 }
	 public void confirmPas(String cpas) {
	 sendtext(ConfirmPassword,cpas);
	 }
	 public void Register() {
	 clickOn(register);
	 }
	 public void Register1() {
	 clickOn(reg1);
	 }
	
		
	
//	//Storing the elements as Methods
//	
//		/**
//	     * Get the current Title of the web page.
//	     *
//	     * @return The current Title.
//	     */
//	public String getTitle() {
//		 return driver.getTitle();
//		 }
//	/**
//     * Enter a button into the button field.
//     *
//     * @param login button to be clicked.
//     */
//	 public void login() {
//		  clickOn(Login);
//		  }
//
//		/**
//	     * Enter a name into the "iname" field.
//	     *
//	     * @param iname The name to be entered.
//	     */
//	
//	 
//	 public void Username(String iname) {
//		 sendtext(username, iname);
//	 }
//	 /**
//	     * Enter an password into the "password" field.
//	     *
//	     * @param ipassword The password to be entered.
//	     */
//	 public void Password(String iPassword) {
//		 sendtext(password, iPassword);
//	 }
//
//		/**
//	     * Click the "Sign Up" button.
//	     */
//	 public void LoginButton() {
//		 clickOn(loginButton);
//	 }
//
//		/**
//	     * Enter a name into the "name" field.
//	     *
//	     * @param name The name to be entered.
//	     * @return the password need to be reentered
//	     */
//	 public String Usernameerror() {
//		 return rettext(usernameerror);
//	 }
//	 /**
//	     * Enter an password into the "password" field.
//	     *
//	     * @param password The password to be entered.
//	     * @return the password need to be reentered
//	     */
//	 public String Passworderror() {
//		 return rettext(passworderror);
//	 }
//	 
//	
//
// 

}