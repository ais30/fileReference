package ust.show.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.show.base.DriverUtils;

/**
 * This class represents a page object for the Main page of a web application.
 */

public class ScenarioPage extends DriverUtils {

	WebDriver driver;

	/**
	 * Constructor for the MainPage class.
	 *
	 * @param driver The WebDriver instance to use for interacting with the page.
	 */

	public ScenarioPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	// WebElement declarations using @FindBy annotations
	// ...

	@FindBy(xpath = "(//a[text()='Apparel '])[1]")
	private WebElement apparel;
	@FindBy(xpath = "(//a[text()='Clothing '])[1]")
	private WebElement clothing;
	@FindBy(xpath = "//select[@aria-label='Select product sort order']")
	private WebElement sortfilter;
	@FindBy(xpath = "(//select[@aria-label='Select product sort order'])/option[5]")
	private WebElement sortselection;
	@FindBy(xpath = "(//a[@href='/levis-511-jeans'])[2]")
	private WebElement productselection;
	@FindBy(xpath = "//button[@id=\"add-to-cart-button-30\"]")
	private WebElement addtocart;
	@FindBy(xpath = "//span[@class=\"cart-label\"]")
	private WebElement cartSelection;
	@FindBy(xpath = "//input[@id=\"termsofservice\"]")
	private WebElement terms;
	@FindBy(xpath = "//button[@id=\"checkout\"]")
	private WebElement checkout;

	// Storing the elements as Methods

	/**
	 * Get the current Title of the web page.
	 *
	 * @return The current Title.
	 */
	public String getTitle() {
		return driver.getTitle();
	}

	/**
	 * Mouseover the particular menu into the menu field .
	 *
	 * @param menu to be mouseovered.
	 */
	public void apparel() {
		mousesOver(apparel);
	}

	/**
	 * Enter the particular menu into the menu field for purchasing.
	 *
	 * @param menu to be clicked.
	 */
	public void clothing() {
		clickOn(clothing);
	}

	/**
	 * click the sort field for purchasing.
	 *
	 * @param menu to be clicked.
	 */
	public void Sortfilter() {
		clickOn(sortfilter);
	}

	/**
	 * click the sort field order for purchasing.
	 *
	 * @param menu to be clicked.
	 */
	public void Sortoption() {
		clickOn(sortselection);
	}

	/**
	 * click the display the products.
	 *
	 * @param menu to be clicked.
	 */
	public void productselection() {
		clickOn(productselection);
	}

	/**
	 * click the display the product for cart.
	 *
	 * @param menu to be clicked.
	 */
	public void addtocart() {
		clickOn(addtocart);
	}

	public void cartselection() {
		clickOn(cartSelection);
	}

	public void terms() {
		ScrollDown();
		clickOn(terms);
	}

	public void Checkout() {
		clickOn(checkout);
	}
}
