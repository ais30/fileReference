package ust.show.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.show.base.DriverUtils;

/**
 * This class represents a page object for the Main page of a web application.
 */

public class SearchPage extends DriverUtils{
	

	WebDriver driver;

	/**
     * Constructor for the MainPage class.
     *
     * @param driver The WebDriver instance to use for interacting with the page.
     */
	
	public SearchPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	} 
	// WebElement declarations using @FindBy annotations
    // ...
	@FindBy(xpath="//input[@class='search-box-text ui-autocomplete-input']")
	WebElement search;
	@FindBy(xpath="//button[@class='button-1 search-box-button']")
	WebElement searchclickbutton;
	@FindBy(xpath="(//button[@class='button-2 product-box-add-to-cart-button'])[2]")
	WebElement product_asus;
	
	@FindBy(xpath=" addtocart_id=add-to-cart-button-4")
	WebElement addtocartsearch;
	
	@FindBy(xpath="//span[@class=\"cart-label\"]")
	private WebElement cartSelection;
	
	@FindBy(xpath="//input[@id=\"termsofservice\"]")
	private WebElement terms;
	
	@FindBy(xpath="//button[@id=\"checkout\"]")
	private WebElement checkout;
	
	public void searchbutton(String value) {
	sendtext(search,value);
	}
	public void searchbuttonclick() {
	clickOn(searchclickbutton);
	}
	public void productasusclick() {
	clickOn(product_asus);
	}
	public void addtocartsearchclick() {
	clickOn(addtocartsearch);
	}
	public void cartselection() {
		clickOn(cartSelection);
	}

	public void terms() {
		ScrollDown();
		clickOn(terms);
	}

	public void Checkout() {
		clickOn(checkout);
	}
}
