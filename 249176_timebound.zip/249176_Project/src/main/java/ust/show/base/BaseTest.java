package ust.show.base;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

/**
 * The BaseTest class serves as the base class for test classes in the test
 * automation framework. It initializes and manages the WebDriver instance and
 * provides common setup methods.
 */

public class BaseTest  extends DriverUtils{
	public static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;

/**
 * This method is annotated with @BeforeTest, which means it will run
 * once. It is responsible for setting up a WebDriver
 * instance based on the specified browser choice.
 *
 */
	@BeforeMethod
	public void setup()
	
	{
		driver=invokebrowser();
		openBrowser("appURL");
		
	}
 

}



