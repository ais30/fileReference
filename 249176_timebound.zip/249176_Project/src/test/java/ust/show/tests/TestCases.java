package ust.show.tests;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ust.show.base.BaseTest;
import ust.show.pages.RegisterPage;
import ust.show.pages.ScenarioPage;
import ust.show.pages.SearchPage;
import ust.show.utils.ExcelUtils;

public class TestCases extends BaseTest {

	String[][] data;

	/**
	 * Provides test data for the test methods.
	 *
	 * @return Object[][] containing test data.
	 */

	@DataProvider(name = "testdata1")
	public Object[][] testdata1() {
		data = ExcelUtils.testdata1();
		return data;

	}

	/**
	 * Provides test data for the test methods.
	 *
	 * @return Object[][] containing test data.
	 */

	@DataProvider(name = "testdata2")
	public Object[][] testdata2() {
		data = ExcelUtils.testdata2();
		return data;

	}

	/**
	 * Test case for login into the user account with valid data.
	 *
	 * @param firstname Name of the user.
	 * @param lastname Name of the user.
	 * @param email of the user.
	 * @param  Password for the user.
	 * @param confirmpassword of the user.
	 */

	@Test(priority = 1, dataProvider = "testdata1")
	public void register(String firstname, String lastname, String mail, String password, String confPass) {
		RegisterPage Reg = new RegisterPage(driver);
		Reg.Register1();
		Reg.FirstName(firstname);
		Reg.LastName(lastname);
		Reg.Email1(mail);
		Reg.Password1(password);
		Reg.confirmPas(confPass);
		Reg.Register();
	}

	// Method to perform login and corresponding assertions
	@Test(priority = 2, dataProvider = "testdata2")
	public void loginTest(String email, String password) {
		String a = "https://demo.nopcommerce.com/";
		driver.get(a);
		RegisterPage Reg = new RegisterPage(driver);
		Reg.login();
		Reg.Email(email);
		Reg.password(password);
		Reg.submit();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
		});
		String j = Reg.errorm();
		if ((email.equals("IncorrectUser"))) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(
						j.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
								+ "No customer account found"));
			});
		} else if (password.equals(" ")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(
						j.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
								+ "No customer account found"));
			});
		} else {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
			});
		}

	}
	@Test(priority = 3)
	public void productSelect() throws InterruptedException {
		String a = "https://demo.nopcommerce.com/";
		driver.get(a);
		ScenarioPage sc = new ScenarioPage(driver);
		sc.apparel();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("(//a[text()='Apparel '])[1]"));
		});
		sc.clothing();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("(//a[text()='Clothing '])[1]")).isSelected());
		});
		sc.Sortfilter();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("//select[@aria-label='Select product sort order']"));
		});
		sc.Sortoption();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("(//select[@aria-label='Select product sort order'])/option[5]")).isDisplayed());
		});
		Thread.sleep(2000);
		sc.productselection();
		sc.addtocart();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//button[@id=\"add-to-cart-button-30\"]")).isSelected());
		});	
		Thread.sleep(2000);
		sc.cartselection();
		sc.ScrollDown();
		sc.terms();
		sc.Checkout();
		
		
	}
	@Test(priority = 4)
	public void Searchselect() throws InterruptedException {
		String a = "https://demo.nopcommerce.com/";
		driver.get(a);
		SearchPage sp = new SearchPage(driver);
		sp.searchbutton("Books");
		sp.searchbuttonclick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("//button[@class='button-1 search-box-button']"));
		});
		sp.productasusclick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("(//button[@class='button-2 product-box-add-to-cart-button'])[2]"));
		});
		sp.addtocartsearchclick();
		Thread.sleep(2000);
		sp.cartselection();
		sp.terms();
		sp.Checkout();
		
	}
	
	
}
