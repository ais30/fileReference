$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"b1b79f3e-f864-4892-854b-baecf731809f","feature":"Login page feature","scenario":"Login with correct credentials","start":1692945876894,"group":1,"content":"","tags":"","end":1692945894801,"className":"passed"},{"id":"21dd8fbf-5ee4-4bfb-b966-f5720c838372","feature":"Login page feature","scenario":"Login page title","start":1692945866376,"group":1,"content":"","tags":"","end":1692945876883,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});