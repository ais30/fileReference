package testCases;

import org.assertj.core.api.SoftAssertions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Base.BaseUI;
import com.ust.POM.AddCart;
import com.ust.POM.CreateLogin;
import com.ust.Utilities.ExcelUtilities;
import com.ust.Utilities.excelUtility;

@Listeners(com.ust.Utilities.SampleListener.class)
public class CaseKaroTestCase extends BaseUI {

	WebDriver driver;
	CreateLogin login;
	AddCart cart;
	String[][] data;

	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		openBrowser("appURL");
	}

	@DataProvider(name = "testdata")
	public Object[][] testdata() {
		data = excelUtility.testdata();
		return data;
	}

	@DataProvider(name = "testData")
	public Object[][] testData() {
		data = ExcelUtilities.testData();
		return data;
	}

	/***************** 
	     *METHOD VALIDATES THE WEBSITE URL & LOGIN 
	 ***************/
	@Test(priority = 0)
	public void accountCase() {
		CreateLogin login = new CreateLogin(driver);
		String a = driver.getCurrentUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("https://casekaro.com/"));
		});

		login.loginaccount();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					driver.findElement(By.xpath("//a[@class='site-header__icon site-header__account']")).isDisplayed());
		});

	}
	
	/***************** 
	   *VALIDATES THE USER ACCOUNT REGISTERATION
	 ***************/
	@Test(priority = 1, dataProvider = "testdata")
	public void accountRegister(String firstName, String lastName, String Email, String password) {
		CreateLogin login = new CreateLogin(driver);

		login.createaccount();

		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h1[text()='Create Account']")).isDisplayed());
		});

		login.FirstName(firstName);
		login.LastName(lastName);
		login.Email(Email);
		login.Password(password);
		login.createbutton();
		login.checkbox();
		login.checkSubmit();

	}

	/***************** 
	   *VALIDATES THE USER LOGIN
	 ***************/
	@Test(priority = 2, dataProvider = "testData")
	public void accountLogin(String Email, String password) {
		CreateLogin login = new CreateLogin(driver);
		login.loginnext();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					driver.findElement(By.xpath("//a[@class='site-header__icon site-header__account']")).isDisplayed());
		});
		login.loginemail(Email);
		login.loginpassword(password);
		login.loginSubmit();
		login.checkbox();
		login.checkSubmit();

	}

	/***************** 
	   *METHOD INDICATES THE SELECTION OF THE PRODUCT AND CARTADD OF THE PRODUCT
	 ***************/
	@Test(priority = 3)
	public void CartAddProduct() {
		AddCart cart = new AddCart(driver);
		cart.popDrop();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[@role='text']")).isDisplayed());
		});

		cart.popfeature();
		cart.FeatureSelect();
		cart.ProductClick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					driver.findElement(By.xpath("//h1[text()='Abstract Printed Pop Holder']")).isDisplayed());
		});

		cart.productCart();
		cart.ContinueShop();

		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[@role='text']")).isDisplayed());
		});

		cart.CaseHome();

	}

}