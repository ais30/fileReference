package com.ust.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Base.BaseUI;

public class AddCart extends BaseUI {

	WebDriver driver;
	CreateLogin createlogin;

	/***************** PAGE FACTORY INITILIZATION **************/
	public AddCart(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/***************** LOCATOR VALUES **************/
	@FindBy(xpath = "//span[text()='Pop Holders']")
	WebElement PopDrop;

	@FindBy(id = "SortBy")
	WebElement popFeatured;

	@FindBy(xpath = "//option[text()='Alphabetically, A-Z']")
	WebElement featureselect;

	@FindBy(xpath = "//a[@class='grid-view-item__link grid-view-item__image-container full-width-link']")
	WebElement productClick;

	@FindBy(id = "AddToCart-product-template")
	WebElement productcart;

	@FindBy(xpath = "//a[@class='btn btn--secondary cart__continue small--hide cart__submit-control']")
	WebElement continueShop;

	@FindBy(xpath = "//a[@class='site-header__logo-link']")
	WebElement caseHome;

	/***************** STORING THE LOCATOR VALUES AS METHODS **************/
	public void popDrop() {
		clickOn(PopDrop);
	}

	public void popfeature() {
		clickOn(popFeatured);
	}

	public void FeatureSelect() {
		clickOn(featureselect);
	}

	public void ProductClick() {
		clickOn(productClick);
	}

	public void productCart() {
		clickOn(productcart);
	}

	public void ContinueShop() {
		clickOn(continueShop);
	}

	public void CaseHome() {
		clickOn(caseHome);
	}
}
