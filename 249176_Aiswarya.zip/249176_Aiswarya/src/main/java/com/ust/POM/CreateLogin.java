package com.ust.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Base.BaseUI;

public class CreateLogin extends BaseUI {
	WebDriver driver;
	CreateLogin createlogin;

	/***************** PAGE FACTORY INITILIZATION **************/
	public CreateLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/***************** LOCATOR VALUES **************/
	@FindBy(xpath = "//a[@class='site-header__icon site-header__account']")
	WebElement Login;

	@FindBy(id = "customer_register_link")
	WebElement CreateAccount;

	@FindBy(id = "FirstName")
	WebElement firstName;

	@FindBy(id = "LastName")
	WebElement lastName;

	@FindBy(id = "Email")
	WebElement Email;

	@FindBy(id = "CreatePassword")
	WebElement password;

	@FindBy(xpath = "//input[@value='Create']")
	WebElement createButton;

	@FindBy(xpath = "//div[@class='recaptcha-checkbox-border']")
	WebElement checkBox;

	@FindBy(xpath = "//a[@class='site-header__icon site-header__account']")
	WebElement checkBoxSubmit;

	@FindBy(xpath = "//a[@class='site-header__icon site-header__account']")
	WebElement LoginNext;

	@FindBy(id = "CustomerEmail")
	WebElement loginEmail;

	@FindBy(id = "CustomerPassword")
	WebElement loginPassword;

	@FindBy(xpath = "//input[@value='Sign In']")
	WebElement loginSubmit;

	/***************** STORING THE LOCATOR VALUES AS METHODS **************/
	public void loginaccount() {
		clickOn(Login);
	}

	public void createaccount() {
		clickOn(CreateAccount);
	}

	public void FirstName(String first) {
		sendtext(firstName, first);
	}

	public void LastName(String last) {
		sendtext(lastName, last);
	}

	public void Email(String Email1) {
		sendtext(Email, Email1);
	}

	public void Password(String Password) {
		sendtext(password, Password);
	}

	public void createbutton() {
		clickOn(createButton);
	}

	public void checkbox() {
		clickOn(checkBox);
	}

	public void checkSubmit() {
		clickOn(checkBoxSubmit);
	}

	public void loginnext() {
		clickOn(LoginNext);
	}

	public void loginemail(String Email) {
		sendtext(loginEmail, Email);
	}

	public void loginpassword(String password) {
		sendtext(loginPassword, password);
	}

	public void loginSubmit() {
		clickOn(loginSubmit);
	}
}
