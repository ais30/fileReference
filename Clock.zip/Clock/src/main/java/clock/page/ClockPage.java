package clock.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import clock.base.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ClockPage extends AndroidActions{
	
	public ClockPage(AndroidDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
	}

	@AndroidFindBy(accessibility="Add alarm")
	private WebElement adDalarm;
	
	@AndroidFindBy(accessibility="8 o'clock")
	private WebElement timehr;
	
	@AndroidFindBy(accessibility="10 minutes")
	private WebElement timemin;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/material_clock_period_am_button")
	private WebElement am;
	
	@AndroidFindBy(xpath="//android.widget.FrameLayout[@content-desc=\"Alarm\"]/android.view.ViewGroup/android.widget.TextView")
	private WebElement alarm;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/material_timepicker_ok_button")
	private WebElement ok;
	
	@AndroidFindBy(accessibility="Collapse alarm")
	private WebElement collapse;
	
	@AndroidFindBy(xpath="//android.widget.CheckBox[@content-desc=\"Monday\"]")
	private WebElement alarmon;
	
	@AndroidFindBy(xpath="//android.widget.FrameLayout[@content-desc=\"Clock\"]/android.view.ViewGroup/android.widget.TextView")
	private WebElement clock;
	
	@AndroidFindBy(accessibility="Add city")
	private WebElement city;
	

	@AndroidFindBy(id="com.google.android.deskclock:id/open_search_view_edit_text")
	private WebElement citysearch;
	
	@AndroidFindBy(xpath="//android.widget.FrameLayout[@content-desc=\"Timer\"]/android.view.ViewGroup/android.widget.TextView")
	private WebElement timer;
	
	@AndroidFindBy(xpath="//android.widget.FrameLayout[@content-desc=\"Stopwatch\"]/android.view.ViewGroup/android.widget.TextView")
	private WebElement stopwatch;
	
	@AndroidFindBy(accessibility="Pause")
	private WebElement pause;
	
	@AndroidFindBy(accessibility="Start")
	private WebElement play;
	
	
	public void alarmClick() {
		alarm.click();
	}
	public void addAlarm() {
		adDalarm.click();
	}
	public void addHr() {
		timehr.click();
	}
	public void addMin() {
		timemin.click();
	}
	public void addAm() {
		am.click();
	}
	public void okClick() {
		ok.click();
	}
	public void monClick() {
		alarmon.click();
	}
	public void collpaseClick() {
		collapse.click();
	}
	public void clockClick() {
		clock.click();
	}
	public void cityClick() {
		city.click();
	}
	public void citySearch(String search) {
		citysearch.sendKeys(search);
	}	
	public void timerClick() {
		timer.click();
	}
	public void stopwatchClick() {
		stopwatch.click();
	}
	public void play() {
		play.click();
	}
	public void pause() {
		pause.click();
	}
}
