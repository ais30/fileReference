//package APItestcases;
//
//import org.junit.Assert;
//import org.testng.annotations.Listeners;
//import org.testng.annotations.Test;
//
//import endpoints.UserEndPoints;
//import io.restassured.response.Response;
//import payload.UserModel;
//import utilities.DataProviders;
//
//@Listeners(utilities.ExtentReportManager.class)
//public class tutorialtestcases {
//	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
//	public void testPostUser(String title,String description)
//	{
//		UserModel user= new UserModel();
//		
//		user.setTitle(title);
//		user.setDescripton(description);
//		Response response =UserEndPoints.createUser(user);
//		response.then().log().all();
//		Assert.assertEquals(response.getStatusCode(), 201);
//		
//	}
//	@Test(priority=2)
//	public void testGetUsers()
//    {
//       Response response = UserEndPoints.getUser();
//       response.then().log().all();
//       Assert.assertEquals(response.getStatusCode(),200);
//    }
//	@Test(priority=3)
//	public void testupdate()
//	{
//		UserModel user=new UserModel();
//		String id="3";
//		user.setTitle("3test");
//		user.setDescripton("description");
//		user.setPublisher(true);
//		
//	        Response response = UserEndPoints.updateUser(id,user);
//	        response.then().log().all();
//	        Assert.assertEquals(response.getStatusCode(),200);
//		
//	}
//	@Test(priority=4,dataProvider="updates",dataProviderClass=DataProviders.class)
//	public void testupdatebyid(String id,String title,String description)
//	{
//		UserModel user=new UserModel();
//		user.setTitle(title);
//		user.setDescripton(description);
//		
//		
//	        Response response = UserEndPoints.updateUser(id,user);
//	        response.then().log().all();
//	        Assert.assertEquals(response.getStatusCode(),200);
//		
//	}
//	@Test(priority=5)
//	public void testGetUsersbyId()
//    {
//		String id="2";
//       Response response = UserEndPoints.getUserbyId(id);
//       response.then().log().all();
//       Assert.assertEquals(response.getStatusCode(),200);
//    }
//	@Test(priority=6)
//	public void testDeleteuserbyID()
//	{
//		String id="20";
//	       Response response = UserEndPoints.deleteUser(id);
//	       response.then().log().all();
//	       Assert.assertEquals(response.getStatusCode(),204);
//	}
//}
