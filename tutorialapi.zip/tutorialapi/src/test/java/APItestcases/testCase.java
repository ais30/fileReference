package APItestcases;

import org.junit.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.UserEndPoints;
import io.restassured.response.Response;

@Listeners(utilities.ExtentReportManager.class)
public class testCase {
	@Test
	public void testGetUsers()
    {
       Response response = UserEndPoints.getUser();
       response.then().log().all();
       Assert.assertEquals(response.getStatusCode(),200);
    }

}
