package ust.show.testcases;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import ust.show.base.BaseTest;
import ust.show.page.AfterStopWatch;
import ust.show.page.ClockPage;

/**This class contains test methods for testing functionalities,
 *  related to a clock application on Android. It interacts with elements on the screen, 
 *  performs assertions, and uses data provided by a data provider method.
 */


@Listeners(ust.show.utilities.SampleListener.class)
public class ClockTestCase extends BaseTest{
	
	@DataProvider(name="timeZoneData")
	public Object[][] getData() throws IOException
	{
		List<HashMap<String, String>>	data =getJsonData(System.getProperty("user.dir")+"\\TestData\\clock.json");
		Object[][] testData = new Object[data.size()][1];

	    for (int i = 0; i < data.size(); i++) {
	        HashMap<String, String> row = data.get(i);
	        testData[i][0] = row.get("city");
	    }

	    return testData;
	}
	
	/**
	 * Test method to verify alarm functionality
	 * @param city
	 * @throws InterruptedException
	 */
	@Test(priority=1,dataProvider="timeZoneData")
	public void alarmTest(String city) throws InterruptedException {
		ClockPage c1=new ClockPage(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/toolbar")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/digital_clock")).isDisplayed());
						
			});
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/date")).isDisplayed());
						
			});
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/fab")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc=\"Alarm\"]")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc=\"Clock\"]")).isDisplayed());
						
			});
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc=\"Timer\"]")).isDisplayed());
						
			});

		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc=\"Bedtime\"]")).isDisplayed());
						
			});
		
		c1.setAlarmField();
		c1.setAddAlarmField();
		c1.setAddHour();
		c1.setAddMin();
		c1.setAlarmZone();
		c1.setAlarm();
		c1.setAlarmSchedule();
		c1.collpaseClick();
		c1.setClock();
		c1.setCityTime();
		c1.setcitySearch(city);
		driver.findElement(By.id("com.google.android.deskclock:id/city_name")).click();
		
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/action_bar_title")).isDisplayed());
						
			});
		Thread.sleep(2000);
		c1.stopwatchClick();
		c1.play();
		Thread.sleep(2000);
		c1.pause();
	}
	
	
	/**
	 * Test method to verify bedtime functionality
	 * @throws InterruptedException
	 */
	@Test(priority = 2)
	public void BedTestCase() throws InterruptedException {
		AfterStopWatch c2 = new AfterStopWatch(driver);
		c2.setBedTime();
		c2.setStartedBedTime();
		c2.setScheduleBedTime();
		c2.setScheduleBedTimeDay();
		Thread.sleep(2000);
		c2.setScreenwakeup();
		SoftAssertions.assertSoftly(softAssertions -> {
		       softAssertions.assertThat(driver.findElement(By.id("com.google.android.deskclock:id/checkbox")).isSelected());
						
			});
		c2.setbedtimesave();
		c2.setbedtimedone();
	}
}