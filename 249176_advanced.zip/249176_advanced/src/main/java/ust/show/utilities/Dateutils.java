package ust.show.utilities;

import java.text.SimpleDateFormat;
import java.util.Date;

/**this class provides a utility method to generate a timeStamp string,
 *  in the format "yyyy.MM.dd.HH.mm.ss" and it is used for tasks like,
 *   creating unique filenames or timeStamps in logs.
 */

public class Dateutils {
	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss")
				.format(new Date());
	}

}
