package ust.show.page;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import ust.show.base.AndroidActions;

/**This class is used for interacting with elements related to setting up bedtime features,
 *  in an Android clock application. It extends AndroidActions for additional functionality,
 *   and it uses annotations for element location and initialization. 
*/

public class AfterStopWatch  extends AndroidActions {
AndroidDriver driver;
	
	public AfterStopWatch(AndroidDriver driver)
	{
		super(driver);
		this.driver =driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this); 
		
	}
	@AndroidFindBy(xpath="//android.widget.FrameLayout[@content-desc=\"Bedtime\"]/android.widget.FrameLayout/android.widget.ImageView")
	private WebElement BedTime;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/bedtime_onboarding_start")
	private WebElement StartedBedTime;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/plus_button")
	private WebElement ScheduleBedTime;
	
	@AndroidFindBy(xpath="//android.widget.CheckBox[@content-desc=\"Tuesday\"]")
	private WebElement ScheduleBedTimeDay;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/checkbox")
	private WebElement Screenwakeup;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/bedtime_onboarding_next")
	private WebElement bedtimesave;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/bedtime_onboarding_done")
	private WebElement bedtimedone;
	
	 public void setBedTime(){
			BedTime.click();	
		}
	 public void setStartedBedTime(){
			StartedBedTime.click();	
		}
	 public void setScheduleBedTime(){
			ScheduleBedTime.click();	
		}
	 public void setScheduleBedTimeDay(){
			ScheduleBedTimeDay.click();	
		}
	 public void setScreenwakeup(){
			Screenwakeup.click();
        }
	 public void setbedtimesave(){
			bedtimesave.click();

        }
	 public void setbedtimedone(){
			bedtimedone.click();

     }
}
