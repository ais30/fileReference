package ust.show.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import ust.show.base.AndroidActions;


/** this class is used for interacting with elements related to clock features,
 *  in an Android application. It extends AndroidActions for additional functionality, 
 *  and it uses annotations for element location and initialization
*/

public class ClockPage extends AndroidActions{
	
	public ClockPage(AndroidDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
	}

	@AndroidFindBy(accessibility="Add alarm")
	private WebElement addalarm;
	
	@AndroidFindBy(accessibility="9 o'clock")
	private WebElement alarmtimehr;
	
	@AndroidFindBy(accessibility="10 minutes")
	private WebElement alarmtimemin;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/material_clock_period_am_button")
	private WebElement alarmzone;
	
	@AndroidFindBy(xpath="//android.widget.FrameLayout[@content-desc=\"Alarm\"]/android.view.ViewGroup/android.widget.TextView")
	private WebElement alarm;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/material_timepicker_ok_button")
	private WebElement setAlarm;
	
	@AndroidFindBy(accessibility="Collapse alarm")
	private WebElement collapse;
	
	@AndroidFindBy(xpath="//android.widget.CheckBox[@content-desc=\"Monday\"]")
	private WebElement alarmSchedule;
	
	@AndroidFindBy(xpath="//android.widget.FrameLayout[@content-desc=\"Clock\"]")
	private WebElement clock;
	
	@AndroidFindBy(accessibility="Add city")
	private WebElement setcity;
	

	@AndroidFindBy(id="com.google.android.deskclock:id/open_search_view_edit_text")
	private WebElement citysearch;
	
	@AndroidFindBy(xpath="//android.widget.FrameLayout[@content-desc=\"Timer\"]/android.view.ViewGroup/android.widget.TextView")
	private WebElement timer;
	
	@AndroidFindBy(uiAutomator ="UiSelector().text(\"Stopwatch\")")
	private WebElement stopwatch;
	
	@AndroidFindBy(accessibility="Pause")
	private WebElement pause;
	
	@AndroidFindBy(accessibility="Start")
	private WebElement play;
	
	
	public void setAlarmField() {
		alarm.click();
	}
	public void setAddAlarmField() {
		addalarm.click();
	}
	public void setAddHour() {
		alarmtimehr.click();
	}
	public void setAddMin() {
		alarmtimemin.click();
	}
	public void setAlarmZone() {
		alarmzone.click();
	}
	public void setAlarm() {
		setAlarm.click();
	}
	public void setAlarmSchedule() {
		alarmSchedule.click();
	}
	public void collpaseClick() {
		collapse.click();
	}
	public void setClock() {
		clock.click();
	}
	public void setCityTime() {
		setcity.click();
	}
	public void setcitySearch(String search) {
		citysearch.sendKeys(search);
	}	
	public void timerClick() {
		timer.click();
	}
	public void stopwatchClick() {
		stopwatch.click();
	}
	public void play() {
		play.click();
	}
	public AfterStopWatch pause()
	{
		pause.click();
		return	new AfterStopWatch(driver);
	}
	
}
