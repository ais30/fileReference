package ust.show.tests;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ust.show.Base.BaseTest;
import ust.show.pages.ParagonLogin;
import ust.show.pages.ParagonReg;
import ust.show.utils.ExcelUtilsLogin;
import ust.show.utils.ExcelUtilsReg;

public class ParagonTest extends BaseTest{
	
	String[][] data;
	
	@DataProvider(name = "testdata")
	public Object[][] testdata()
	{
		data= ExcelUtilsReg.testdata();
		return data;

	}
	
	@DataProvider(name = "TestData")
	public Object[][] TestData()
	{
		data= ExcelUtilsLogin.TestData();
		return data;

	}
	
	@Test(priority =1,dataProvider = "testdata")
	public void registerClick(String first,String last, String email,String pass, String conpass, String num){
		ParagonReg p=new ParagonReg(driver);
		String expectedURL = "https://www.paragonfootwear.com/";
		driver.get(expectedURL);
		String actualURL = driver.getCurrentUrl();
		Assert.assertEquals(actualURL, expectedURL, "URLs do match!");
		p.CloseButton();

		p.LoginButton();
		p.SignupButton();
		
		
		
		String f=p.firstnameempty();
		String l=p.lastnameempty();
		String e=p.emailEmpty();
		String ps=p.passworderror();
		String cp=p.confirmpassempty();
		String m=p.mobileerror();
		
		if(first.equals(" ")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(f.equalsIgnoreCase("This is a required field."));
			});
		}
		else if(last.equals(" ")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(l.equalsIgnoreCase("This is a required field."));
			});
		}
		else if(email.equals("xyz@")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(e.equalsIgnoreCase("Please enter a valid email address (Ex: johndoe@domain.com)."));
			});
		}
		else if(pass.equals("abc")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(ps.equalsIgnoreCase("Minimum length of this field must be equal or greater than 8 symbols. Leading and trailing spaces will be ignored."));
			});
		}
		else if(conpass.equals("xyz")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(cp.equalsIgnoreCase("Please enter the same value again."));
			});
		}
			else if(num.equals(" ")) {
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(m.equalsIgnoreCase("This is a required field."));
				});
		}
		
		
		p.NameFirst(first);
		p.NameLast(last);
		p.EmailAdd(email);
		p.Password(pass);
		p.PasswordConf(conpass);
		p.MobileNum(num);
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("firstname")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("lastname")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("email_address")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("password")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("password-confirmation")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("mobile")).isDisplayed());
			
		});
		
		
		p.SignupClick();
		
	}
	
	@Test(priority =2,dataProvider = "TestData")
	public void LoginClick(String email, String pass) throws InterruptedException {
		ParagonLogin p=new ParagonLogin(driver);
		p.CloseButton();
		p.LoginButton();
		p.EmailLogin(email);
		p.PasswordLogin(pass);
		p.LoginClick();
		
		String e=p.emailEmpty();
		String l=p.ErrorLogin();
		if(email.equals("anju@gmail.com") || pass.equals("IncorrectPassword")) {
			SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(l.equalsIgnoreCase("The account sign-in was incorrect or your account is disabled temporarily. Please wait and try again later."));
			});
			Thread.sleep(1000);
			
		}
		else if(email.equals("IncorrectMail") && pass.equals("anju@12345")) {
			 SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(e.equalsIgnoreCase("Please enter a valid email address (Ex: johndoe@domain.com)."));
			 });
			 Thread.sleep(1000);
		}
		else if(email.equals("IncorrectMail") && pass.equals("IncorrectPassword")) {
			 SoftAssertions.assertSoftly(softAssertions->{
				 softAssertions.assertThat(l.equalsIgnoreCase("The account sign-in was incorrect or your account is disabled temporarily. Please wait and try again later."));
			 });
			 Thread.sleep(1000);
		}
		else
		{
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.getCurrentUrl().contains("https://www.paragonfootwear.com/customer/account/index/"));
		
			});
		}
		
	}
}
