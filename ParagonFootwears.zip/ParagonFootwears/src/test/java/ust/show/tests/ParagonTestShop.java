package ust.show.tests;

import org.assertj.core.api.SoftAssertions;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ust.show.Base.BaseTest1;
import ust.show.pages.AddressLoc;
import ust.show.pages.LocationSite;
import ust.show.pages.ParagonLogin;
import ust.show.pages.ParagonShop;
import ust.show.pages.ScenarioPage;
import ust.show.utils.ExcelLoginMain;
import ust.show.utils.ExcelUtilsAddress;

public class ParagonTestShop extends BaseTest1{
	String[][] data;
	@DataProvider(name = "TestData")
	public Object[][] TestData()
	{
		data= ExcelLoginMain.TestData();
		return data;

	}
	
	@DataProvider(name = "testData")
	public Object[][] testData()
	{
		data= ExcelUtilsAddress.testData();
		return data;

	}
	
	@Test(priority =1,dataProvider = "TestData")
	public void LoginClick(String email, String pass) {
		ParagonLogin p=new ParagonLogin(driver);
		p.CloseButton();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//img[@title='Paragon']")).isDisplayed());
			
		});
		p.LoginButton();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[text()='Login']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("email")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("pass")).isDisplayed());
			
		});
		
		p.EmailLogin(email);
		p.PasswordLogin(pass);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[text()='Forgot Password?']")).isDisplayed());
			
		});
		p.LoginClick();
	}
	
	@Test(priority =2)
	public void LocationsStore() {
		LocationSite p=new LocationSite(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("dLabel")).isDisplayed());
			
		});
		p.LocatorStore();
		p.SelectBranch();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//li[@class='item Footwear shop near me | Shop store- Paragon Footwear']")).isDisplayed());
			
		});
		
		
		p.SelectState();
		p.SelectKerala();
		p.SelectCity();
		p.SelectKottayam();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[text()='Paragon Exclusive Retail Outlet']")).isDisplayed());
			
		});
		p.SelectLocation();
		p.SelectChngsry();
		p.LocatorStore();
		p.SelectStore();
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//select[@class='state select-list']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//select[@class='city select-list']")).isDisplayed());
			
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//select[@class='storesInCity select-list']")).isDisplayed());
			
		});
		p.SelectState();
		p.SelectKerala();
		p.SelectCity();
		p.SelectKottayam();
		p.SelectLocation();
		p.StoreLocation();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//h4[text()='Find a Store Near You']")).isDisplayed());
			
		});
		
	}
	
	@Test(priority =3,dataProvider = "testData")
	public void AddressBook(String comp,String num,String add, String city, String zip) {
		AddressLoc p=new AddressLoc(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[@class='action showcart']")).isDisplayed());
			
		});
		p.LoginButton();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[text()='Address Book']")).isDisplayed());
			
		});
		p.BookAddress();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("(//div[@class='block-title'])[2]")).isDisplayed());
			
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//button[@role='add-address']")).isDisplayed());
			
		});
		p.AddressAdd();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[text()='Contact Information']")).isDisplayed());
			
		});
		p.Detailscompany(comp);
		p.NumTelephone(num);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//span[text()='Address']")).isDisplayed());
			
		});
		p.DetailsAddress(add);
		p.DetailsState();
		p.SelectState();
		p.DetailsCity(city);
		p.Detailszip(zip);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//button[@class='action save primary']")).isDisplayed());
			
		});
		p.AddressSave();
		p.PageMain();
	}
	
	@Test( priority=4 )
	public void Wishclick()
	{
		
		ParagonShop W1=new ParagonShop(driver);
		W1.Close();
		W1.Women();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[@id=\"om\"]/ul/li[3]//span")).isSelected());
        	});
		W1.Slippers();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[@id=\"om\"]//li[3]/ul//ul/li[1]/a/span")).isSelected());
        	});
		W1.Style();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[text()='Style']")).isSelected());
        	});
		W1.StyleSelect();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//li[@data-label='FLIP-FLOPS']")).isSelected());
        	});
		W1.Size();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[text()='Size']")).isSelected());
        	});
		W1.SizeSelect();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[@data-option-label='7 (25.1 cm)'] ")).isSelected());
        	});
		W1.Price();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[text()='Price']")).isSelected());
        	});
		W1.PriceRange();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//li[@data-label='Rs.300.00 - Rs.399.99']")).isSelected());
        	});
		
		W1.Like();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//img[@class='wishlist-img'])[1]")).isSelected());
        	});
		W1.ContinueHere();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//a[text()='here']")).isSelected());
        	});
	}
	
	@Test(priority =5 )
	public void Salesclick() throws InterruptedException {
		ScenarioPage s1= new ScenarioPage(driver);
		 s1.close();
		s1.PageMain();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//img[@title='Paragon']")).isSelected());
        	});
		s1.saleclick();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//a[@class=\"level-top\"]/span")).isSelected());
        	});
		s1.Style();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[text()=\"Style\"]")).isSelected());
        	});
		s1.flipflops();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[text()=\"Style\"]")).isSelected());
        	});
		s1.SizeSelect();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[@id=\"narrow-by-list\"]//form/div/div[4]/a/div")).isSelected());
        	});
		s1.priceclick();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[@id=\"narrow-by-list\"]/div[4]/div[1]")).isSelected());
        	});
		s1.pricerange();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[@id=\"narrow-by-list\"]//div[2]//li[3]/a//span[2]")).isSelected());
        	});
		s1.productclick();
		s1.productsize();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[@id=\"option-label-size-179-item-399\"]")).isSelected());
        	});
		s1.addtocart();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//button[@id=\"product-addtocart-button\"]")).isSelected());
        	});
		Thread.sleep(2000);
		s1.cartclick();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//a[@class='action showcart active']")).isDisplayed());
        	});
     	s1.cartview();
     	SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//span[text()='View and Edit Cart']")).isDisplayed());
        	});
    	
		s1.checkoutproceed();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[text()='Shipping Address']")).isDisplayed());
        	});
		
		s1.CheckAddress();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//button[@class='button action continue primary']")).isDisplayed());
        	});
		driver.navigate().to("https://www.paragonfootwear.com/");
	}
 @Test(priority =6 )
	public void categoryclick() throws InterruptedException {
		ScenarioPage s1= new ScenarioPage(driver);
		String a=driver.getCurrentUrl();
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://www.paragonfootwear.com/"));
		 });
		s1.close();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.id("bio_ep_close")).isSelected());
        	});
		s1.mencategory();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[@id=\"om\"]//li[2]/a")).isSelected());
        	});
		s1.brand();
		
		s1.stylesandals();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//li[@data-label=\"SANDAL\"]")).isSelected());
        	});
		s1.productselection();
		
		s1.colourchange();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//a[@class=\"active\"]")).isSelected());
        	});
		s1.addtocart();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//button[@id=\"product-addtocart-button\"]")).isSelected());
        	});
		Thread.sleep(2000);
		s1.cartclick();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//a[@class='action showcart active']")).isDisplayed());
        	});
	
		s1.cartview();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//span[text()='View and Edit Cart']")).isDisplayed());
        	});
		
		s1.checkoutproceed();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[text()='Shipping Address']")).isDisplayed());
        	});
		
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//div[text()='Shipping Address']")).isDisplayed());
        	});
		
		s1.CheckAddress();
		driver.navigate().to("https://www.paragonfootwear.com/");
		
}
}
