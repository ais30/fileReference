package stepDefinition;


import org.openqa.selenium.WebDriver;
import org.testng.Assert;



import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import ust.show.Base.BrowserConfig;
import ust.show.pages.ParagonReg;


public class ParagonSteps {
	public static String title;
	public WebDriver driver=BrowserConfig.geTBrowser();
	public  ParagonReg p=new ParagonReg(driver);
	
	
}
