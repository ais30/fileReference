package ust.show.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.show.Base.DriverUtils;




public class ScenarioPage extends DriverUtils{
	

	WebDriver driver;

	public ScenarioPage(WebDriver rdriver) {
		this.driver = rdriver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@class=\"level-top\"]/span")
	private WebElement saleclick;
	
	@FindBy(xpath="//div[text()=\"Style\"]")
	 private WebElement Style;
	
	 @FindBy(xpath="//li[@data-label=\"FLIP-FLOPS\"]")
	 private WebElement StyleSelect;
	
	@FindBy(xpath="//li[@data-label='FLIP-FLOPS']")
	private WebElement flipflops;
	
	@FindBy(xpath="//div[@id=\"narrow-by-list\"]//form/div/div[4]/a/div")
	 private WebElement SizeSelect;
	
	 
	 @FindBy(xpath="//div[@id=\"narrow-by-list\"]/div[3]/div[1]")
	 private WebElement Size;
	
	@FindBy(xpath="//div[@id=\"narrow-by-list\"]/div[4]/div[1]")
	private WebElement priceclick;
	
	@FindBy(xpath="//div[@id=\"narrow-by-list\"]//div[2]//li[3]/a//span[2]")
	private WebElement pricerange;
	
	@FindBy(xpath="//div[@id=\"product-item-info_30409\"]/div[1]/a//img")
	private WebElement productclick;
	
	@FindBy(xpath="//div[@id=\"option-label-size-179-item-399\"]")
	private WebElement productsize;
	
	@FindBy(xpath="//button[@id=\"product-addtocart-button\"]")
	private WebElement addtocart;
	
	@FindBy(xpath="//a[@class='action showcart']")
	private WebElement cartclick;
	
	@FindBy(xpath="//span[text()='View and Edit Cart']")
	private WebElement cartview;
	
	@FindBy(xpath="//a[@class='prochk action primary checkout']")
	private WebElement checkoutproceed;
	
	//*********men category scenario*********//
	
	@FindBy(id="bio_ep_close")
	private WebElement close;
	
	@FindBy(xpath="//div[@id=\"om\"]//li[2]/a")
	private WebElement mencategory;
	
	@FindBy(xpath="//li[@class=\"level2 nav-2-2-1 first\"]/a/span")
	private WebElement brand;
	
	@FindBy(xpath="//li[@data-label=\"SANDAL\"]")
	private WebElement stylesandals;
	
	@FindBy(xpath="//div[@class=\"inside-slider-info\"]")
	private WebElement productselection;
	
	@FindBy(xpath="//a[@class=\"active\"]")
	private WebElement colourchange;
	
	@FindBy(xpath="//a[@class=\"continue-shopping\"]")
	private WebElement continuebutton;
	
	@FindBy(xpath="//img[@title='Paragon']")
	private WebElement MainPage;
	
	@FindBy(xpath="//button[@class='button action continue primary']")
	private WebElement AddressCheckout;
	
	public String getTitle() {
		 return driver.getTitle();
		 }
	 public void saleclick() {
		 clickOn(saleclick);
		 }
	 
	 public void Style() {
		 clickOn(Style);
		 
	 }
	 public void StylesSelect() {
		 clickOn(StyleSelect);
		 
	 }
	 public void flipflops() {
		 clickOn(flipflops);
	 }
	 
	 public void SizeSelect() {
		 clickOn(SizeSelect);
	 }
	 
	 public void Size() {
		 clickOn(Size);
	 }
	 
	 public void priceclick() {
		 clickOn(priceclick);
	 }
	 public void pricerange() {
		 clickOn(pricerange);
	 }
	 public void productclick() {
		 clickOn(productclick);
	 }

	 public void productsize() {
		 clickOn(productsize);
	 }
	 public void addtocart() {
		 clickOn(addtocart);
	 }
	 public void cartclick() throws InterruptedException {
		 jsClick(cartclick,driver);
	 }
	 public void cartview() {
		 clickOn(cartview);
	 }
	 public void checkoutproceed() {
		 clickOn(checkoutproceed);
	 }
	 public void mencategory() {
		 mousehOver(mencategory);
	 }
	 public void brand() {
		 clickOn(brand);
	 }
	 public void stylesandals() {
		 clickOn(stylesandals);
	 }
	 public void close() {
		clickOn(close); 
	 }
	 public void productselection() {
		 clickOn(productselection);
	 }
	 public void colourchange() {
			clickOn(colourchange); 
		 }
     public void continuebutton() {
    	 clickOn(continuebutton);
     }
     
     public void PageMain()
 	{
 		clickOn(MainPage);
 	}
     
     public void CheckAddress()
  	{
  		clickOn(AddressCheckout);
  	}
	
}