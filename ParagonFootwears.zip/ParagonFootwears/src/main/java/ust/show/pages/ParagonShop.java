package ust.show.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.show.Base.DriverUtils;

public class ParagonShop extends DriverUtils{

	 private WebDriver driver;
	 public ParagonShop(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}	
	 
	
	
	//product wishlist
	
	
	 @FindBy( id="bio_ep_close")
		private WebElement Close;
	 
	    @FindBy(xpath="//div[@id=\"om\"]/ul/li[3]//span")
		private WebElement Women;
		
		@FindBy(xpath="//div[@id=\"om\"]//li[3]/ul//ul/li[1]/a/span")
		private WebElement Slippers;
	 
		@FindBy(xpath="//div[text()='Style']")
		private WebElement Style;

		@FindBy(xpath="//li[@data-label='FLIP-FLOPS']")
		private WebElement StyleSelect;
		
		@FindBy(xpath="//div[text()='Size']")
		private WebElement Size;
		
		@FindBy(xpath="//div[@data-option-label='7 (25.1 cm)'] ")
		private WebElement SizeSelect;
		
		@FindBy(xpath="//div[text()='Price']")
		private WebElement Price;
		
		@FindBy(xpath="//li[@data-label='Rs.300.00 - Rs.399.99']")
		private WebElement PriceRange;
		
		@FindBy(xpath="//div[text()='Brands']")
		private WebElement Brands;
		
		@FindBy(xpath="//li[@data-label='PARAGON']")
		private WebElement Brandselect;
		
		@FindBy(xpath="(//img[@class='wishlist-img'])[1]")
		private WebElement Like;
		
		@FindBy(xpath="//a[text()='here']")
		private WebElement ContinueHere;
		
		
	  public String getTitle() {
		  return driver.getTitle();
	  }
	  public void Close()
		{
			clickOn(Close);
		}
	    
	 public void Women() {
			mousehOver(Women);
		}

	public void Slippers()
	{
		clickOn(Slippers);
	}
	public void Style()
	{
		clickOn(Style);
	}
	public void StyleSelect()
	{
		clickOn(StyleSelect);
	}
	public void Size()
	{
		clickOn(Size);
	}
	public void SizeSelect()
	{
		clickOn(SizeSelect);
	}
	public void Price()
	{
		clickOn(Price);
	}
	public void PriceRange()
	{
		clickOn(PriceRange);
	}
	public void Brands()
	{
		clickOn(Brands);
	}
	public void Brandselect()
	{
		clickOn(Brandselect);
	}
	public void Like()
	{
		clickOn(Like);
	}
	public void ContinueHere()
	{
		clickOn(ContinueHere);
	}
	
}


