package ust.show.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.show.Base.DriverUtils;

public class ParagonReg extends DriverUtils {
	
	 private WebDriver driver;
	 public ParagonReg(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}	
	 
	@FindBy(id="bio_ep_close")
	private WebElement close;

	@FindBy(xpath="(//img[@class='imgs'])[2]")
	private WebElement Login;
		
	@FindBy(xpath="//a[text()='Sign up']")
	private WebElement Signup;
		
	@FindBy(id="firstname")
	private WebElement firstName;
		
	@FindBy(id="lastname")
	private WebElement lastname;
		
	@FindBy(id="email_address")
	private WebElement emailaddress;
		
	@FindBy(id="password")
	private WebElement password;
		
	@FindBy(id="password-confirmation")
	private WebElement ConfPassword;
		
	@FindBy(id="mobile")
	private WebElement mobile;
		
	@FindBy(xpath="(//span[text()='Create an Account'])[1]")
	private WebElement CreateClick;
	
	
	@FindBy(id="firstname-error")
	private WebElement firstNameerr;
		
	@FindBy(id="lastname-error")
	private WebElement lastnameerr;
		
	@FindBy(id="email_address-error")
	private WebElement emailaddresserr;
		
	@FindBy(id="password-error")
	private WebElement passworderr;
		
	@FindBy(id="password-confirmation-error")
	private WebElement ConfPassworderr;
		
	@FindBy(id="mobile-error")
	private WebElement mobileerr;
	
		
		public void CloseButton()
		{
			clickOn(close);
		}
		
		public void LoginButton()
		{
			clickOn(Login);
		}
		
		public void SignupButton()
		{
			clickOn(Signup);
		}
		
		public void NameFirst(String first)
		{
			sendtext(firstName,first);
		}
		
		public void NameLast(String last)
		{
			sendtext(lastname,last);
		}
		
		public void EmailAdd(String email)
		{
			sendtext(emailaddress,email);
		}
		
		public void Password(String pass)
		{
			sendtext(password,pass);
		}
		
		public void PasswordConf(String conpass)
		{
			sendtext(ConfPassword,conpass);
		}
		
		public void MobileNum(String num)
		{
			sendtext(mobile,num);
		}
		
		public void SignupClick()
		{
			clickOn(CreateClick);
		}
		
		public String firstnameempty()
		{
			return rettext(firstNameerr);
		}
		
		public String lastnameempty()
		{
			return rettext(lastnameerr);
			
		}
		
		public String emailEmpty()
		{
			return rettext(emailaddresserr);
		}
		
		public String passworderror()
		{
			return rettext(passworderr);
		}
		
		public String confirmpassempty()
		{
			return rettext(ConfPassworderr);
		}
		
		public String mobileerror()
		{
			return rettext(mobileerr);
		}
		
		

}
