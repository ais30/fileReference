package ust.show.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.show.Base.DriverUtils;

public class LocationSite extends DriverUtils{

	 private WebDriver driver;
	 public LocationSite(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}	
	 
	@FindBy(xpath="//li[text()='Store locator']")
	private WebElement StoreLocator;
		
	@FindBy(xpath="(//a[text()='Branch'])[1]")
	private WebElement BranchSelect;
		
	@FindBy(xpath="//select[@class='state select-list']")
	private WebElement StateSelect;
		
	@FindBy(xpath="//option[@value='Kerala']")
	private WebElement KeralaSelect;
		
	@FindBy(xpath="//select[@class='city select-list']")
	private WebElement CitySelect;
		
	@FindBy(xpath="//option[@value='Kottayam']")
	private WebElement KottayamSelect;
		
	@FindBy(xpath="//select[@class='storesInCity select-list']")
	private WebElement LocationSelect;
		
	@FindBy(xpath="//option[@value='Changanachherry']")
	private WebElement chngsrySelect;
		
		
		
		
	@FindBy(xpath="//a[text()='Store ']")
	private WebElement StoreSelect;
		
	@FindBy(xpath="//option[@value='Near Mammen Mappilai Hall']")
	private WebElement LocationStore;
		
		
		public void LocatorStore()
		{
			mousehOver(StoreLocator);
		}
		
		public void SelectBranch()
		{
			clickOn(BranchSelect);
		}
		
		public void SelectState()
		{
			clickOn(StateSelect);
		}
		
		public void SelectKerala()
		{
			clickOn(KeralaSelect);
		}
		
		public void SelectCity()
		{
			clickOn(CitySelect);
		}
		
		public void SelectKottayam()
		{
			clickOn(KottayamSelect);
		}
		
		public void SelectLocation()
		{
			clickOn(LocationSelect);
		}
		
		public void SelectChngsry()
		{
			clickOn(chngsrySelect);
		}
		
		public void SelectStore()
		{
			clickOn(StoreSelect);
		}
		
		public void StoreLocation()
		{
			clickOn(LocationStore);
		}
		

}
