package ust.show.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.show.Base.DriverUtils;

public class ParagonLogin extends DriverUtils {
	
	 private WebDriver driver;
	 public ParagonLogin(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}	
	 
	@FindBy(id="bio_ep_close")
	private WebElement close;
	
	@FindBy(xpath="(//img[@class='imgs'])[2]")
	private WebElement Login;
	 
	@FindBy(xpath="//a[text()='Login']")
	private WebElement LoginClick;
		
	@FindBy(id="email")
	private WebElement LoginEmail;
		
	@FindBy(id="pass")
	private WebElement LoginPassword;
		
	@FindBy(id="send2")
	private WebElement LoginButton;
	
	@FindBy(id="email_address-error")
	private WebElement emailaddresserr;
	
	@FindBy(xpath="//div[text()='The account sign-in was incorrect or your account is disabled temporarily. Please wait and try again later.']")
	private WebElement loginerror;
	
	
	public void CloseButton()
	{
		clickOn(close);
	}
	
	public void LoginButton()
	{
		clickOn(Login);
	}
	
	public void EmailLogin(String email)
	{
		sendtext(LoginEmail,email);
	}
	
	public void PasswordLogin(String pass)
	{
		sendtext(LoginPassword,pass);
	}
	
	public void LoginClick()
	{
		clickOn(LoginButton);
	}
	
	public String emailEmpty()
	{
		return rettext(emailaddresserr);
	}
	
	public String ErrorLogin()
	{
		return rettext(loginerror);
	}
}
