package ust.show.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.show.Base.DriverUtils;

public class AddressLoc extends DriverUtils{

	 private WebDriver driver;
	 public AddressLoc(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}	
	
	@FindBy(xpath="(//img[@class='imgs'])[2]")
	private WebElement Login;
	 
	@FindBy(xpath="//a[text()='Address Book']")
	private WebElement AddressBook;
	
	@FindBy(id="company")
	private WebElement CompanyDetails;
	
	@FindBy(id="telephone")
	private WebElement TelephoneNum;
	
	@FindBy(id="street_1")
	private WebElement AddressDetails;
	
	@FindBy(id="region_id")
	private WebElement StateDetails;
	
	@FindBy(xpath="//option[text()='Kerala']")
	private WebElement StateSelect;
	
	@FindBy(id="city")
	private WebElement CityDetails;
	
	@FindBy(id="zip")
	private WebElement ZipDetails;
	
	@FindBy(xpath="//span[text()='Save Address']")
	private WebElement SaveAddress;
	
	@FindBy(xpath="//button[@class='action primary add']")
	private WebElement AddAddress;
	
	@FindBy(xpath="//img[@title='Paragon']")
	private WebElement MainPage;
	
	public void LoginButton()
	{
		clickOn(Login);
	}
	
	public void BookAddress()
	{
		clickOn(AddressBook);
	}
	
	public void Detailscompany(String comp)
	{
		sendtext(CompanyDetails,comp);
	}
	
	public void NumTelephone(String num)
	{
		sendtext(TelephoneNum,num);
	}
	
	public void DetailsAddress(String add)
	{
		sendtext(AddressDetails,add);
	}
	
	public void DetailsState()
	{
		clickOn(StateDetails);
	}
	
	public void SelectState()
	{
		clickOn(StateSelect);
	}
	
	public void DetailsCity(String num)
	{
		sendtext(CityDetails,num);
	}
	
	public void Detailszip(String num)
	{
		sendtext(ZipDetails,num);
	}
	
	public void AddressSave()
	{
		clickOn(SaveAddress);
	}
	
	public void AddressAdd()
	{
		clickOn(AddAddress);
	}
	
	public void PageMain()
	{
		clickOn(MainPage);
	}
}
