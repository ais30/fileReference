package base;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class BaseTest_contact {
	public AndroidDriver driver;
	
	@BeforeTest
	public void message() throws MalformedURLException {

		DesiredCapabilities capabilities=new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME,"UiAutomator2");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,"LibPhone");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE,"com.google.android.contacts");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY,"com.android.contacts.activities.PeopleActivity");

		driver=new AndroidDriver(new URL("http://127.0.0.1:4723/"),capabilities);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	public List<HashMap<String, String>> getJsonData(String jsonFilePath) throws IOException {
		//System.getProperty("user.dir")+"/src/test/java/com/AppiumFramework/testdata/eCommerce.json";
				// conver json file content to json string
				String jsonContent = FileUtils.readFileToString(new File(jsonFilePath),StandardCharsets.UTF_8);
				ObjectMapper mapper = new ObjectMapper();
				List<HashMap<String, String>> data = mapper.readValue(jsonContent,
						new TypeReference<List<HashMap<String, String>>>() {
						});
				return data;
			} 


}
